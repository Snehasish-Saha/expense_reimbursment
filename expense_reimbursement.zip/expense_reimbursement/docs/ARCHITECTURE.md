# Architecture Overview

## Stack

- **Django 5 + Django REST Framework** — batteries-included ORM, admin, and a
  mature REST toolkit (serializers, viewsets, filtering, pagination).
- **SQLite** by default (zero setup for review); swappable to **PostgreSQL**
  via environment variables (`DB_ENGINE`, `DB_NAME`, ...) with no code change.
- **SimpleJWT** for stateless authentication (access + refresh tokens).
- **django-filter** for declarative query filtering.
- **drf-spectacular** for an OpenAPI schema + Swagger UI (`/api/docs/`),
  in addition to the hand-written `docs/API.md`.

## App layout

The project is split into four Django apps, each with a single clear
responsibility:

```
apps/
  common/          Cross-cutting concerns shared by every domain app:
                      - Currency / ExchangeRate / OrganizationSettings (multi-currency)
                      - AuditLog (generic, append-only audit trail)
                      - CurrencyConverter / AuditService (shared services)
                      - Custom exception handling, pagination, permissions
  accounts/        User (custom model, role-based), Department
  expenses/        ExpenseCategory, Expense, Receipt — recording & editing expenses
  reimbursements/  ReimbursementRequest, ReimbursementRequestItem, RequestComment
                      + services.py: the approval-workflow state machine
```

`common` has no dependency on the other three; `expenses` depends on
`accounts` + `common`; `reimbursements` depends on `expenses` (each request
item wraps an `Expense`). This keeps the dependency graph a DAG and makes
each app independently testable.

## Service layer (`apps/reimbursements/services.py`)

All state transitions for a reimbursement request (`submit`, `approve`,
`reject`, `cancel`, `add_comment`) are implemented as plain functions in a
service module, not inline in views or model `save()` overrides. Reasons:

1. **Single source of truth for business rules.** "Only PENDING requests
   can be approved", "only the assigned manager can decide", "an expense in
   DRAFT is the only thing eligible for submission" all live in one file, so
   a new API endpoint (or a future Celery task, admin action, or management
   command) can't bypass them.
2. **Testability without HTTP.** `apps/reimbursements/tests.py` calls these
   functions directly — no test client, no auth boilerplate — which keeps
   the business-logic tests fast and focused.
3. **Transactional integrity.** Every transition is wrapped in
   `transaction.atomic()` and uses `select_for_update()` on the rows it
   mutates, so two concurrent "submit" calls can't both grab the same
   DRAFT expense (the classic double-submit race), and a request can't be
   approved and rejected in the same instant by two managers.
4. **Guaranteed audit logging.** Every transition ends with a call to
   `AuditService.log(...)`. Because it's inside the same function that
   performs the mutation, it's structurally impossible to add a new
   transition without also writing its audit entry.

## Duplicate-reimbursement prevention

Two layers, deliberately redundant:

- **Domain rule:** `Expense.status` is `DRAFT` → `PENDING_APPROVAL` →
  `REIMBURSED` (or back to `DRAFT` on reject/cancel). Only `DRAFT` expenses
  are eligible to be added to a new request (`services.submit_request`
  checks `expense.status != DRAFT` and raises `DuplicateRequestError`).
  This is also what the API surface exposes to clients ("why can't I
  submit this expense again?" → "it's not in DRAFT status").
- **Database constraint:** `ReimbursementRequestItem` has a
  `UniqueConstraint(fields=["request", "expense"])` as a defense-in-depth
  guard against the same expense being attached twice *within a single
  request* (e.g. a buggy client submitting duplicate IDs). The service
  layer also explicitly rejects duplicate IDs in the same submission
  payload before hitting the DB.
- **Row locking:** `select_for_update()` on the candidate expenses during
  submission prevents a race between two simultaneous submissions of the
  same expense from two different requests.

## Multi-currency design

- Every `Expense` carries its own `currency` (defaults to the employee's
  `home_currency`, but can be overridden per-expense — e.g. a trip paid in
  a third currency).
- `OrganizationSettings.base_currency` is the single reporting/reimbursement
  currency (e.g. the employer's home currency). It's a **database row**, not
  a Django setting, so an admin can change it at runtime via
  `PATCH /api/org-settings/` without a deploy.
- `ExchangeRate` is **versioned by `effective_date`**, not a single mutable
  "current rate" row. This means:
  - The rate used for a given submission is the latest rate on/before that
    date — reproducible after the fact.
  - `ReimbursementRequestItem` **snapshots** `original_amount`,
    `original_currency`, `exchange_rate_used`, and `converted_amount` at
    submission time. If the org's exchange rates or base currency change
    later, previously-submitted/approved requests are unaffected — their
    historical totals stay exactly as they were reported and approved.
- Rates are currently seeded/maintained manually (via `seed_demo_data` or
  the `/api/exchange-rates/` admin endpoint). See "Improvements" in the
  README for wiring this to a live FX provider.

## Auditability

`AuditLog` is a single generic table (`content_type` + `object_id`) rather
than a per-model audit table, so:

- Every domain event — expense created/edited/deleted, receipt
  uploaded/removed, request submitted/approved/rejected/cancelled, comment
  added — is captured uniformly.
- `GET /api/expenses/{id}/audit/` and
  `GET /api/reimbursement-requests/{id}/audit/` return the full,
  chronologically-ordered history for that object, including who did it,
  when, from what IP, and a JSON diff/metadata payload.
- The admin site additionally exposes a read-only, non-deletable `AuditLog`
  list for compliance review.

## Authorization model

Three roles (`EMPLOYEE`, `MANAGER`, `ADMIN`), enforced at two levels:

- **Object-level via queryset scoping**: `get_queryset()` on each viewset
  filters to what the caller is allowed to see (employees: their own data;
  managers: their direct reports', plus an explicit `?scope=department`
  opt-in for read-only departmental visibility; admins: everything).
- **Action-level via the service layer**: e.g. `services.submit_request`
  independently re-checks `expense.employee_id == employee.id` and
  `services._assert_can_decide` re-checks that the caller is the
  employee's assigned manager (or an admin) — so even if a queryset filter
  were ever loosened by mistake, the mutation itself remains guarded.

## Error handling

A single custom DRF exception handler
(`apps/common/exceptions.py::custom_exception_handler`) normalizes every
error response to `{"detail": "...", ["errors": {...}]}` and maps our
internal `DomainError` family (`DuplicateRequestError`,
`InvalidStateTransitionError`, `NotOwnerError`, ...) to the right HTTP
status codes (400/403/409), so business-rule violations never surface as
unhandled 500s.

## Request/response flow (submit → approve example)

```
Employee                         API                          Service layer                      DB
   |  POST /expenses/                |                              |                                |
   |--------------------------------->  ExpenseViewSet.create        |                                |
   |                                  |----------------------------->|  Expense(status=DRAFT)          |
   |  POST /reimbursement-requests/  |                              |                                |
   |    {expense_ids:[1,2]}          |                              |                                |
   |--------------------------------->  ReimbursementRequestViewSet |                                |
   |                                  |----------------------------->  services.submit_request        |
   |                                  |                              |  - lock + validate expenses     |
   |                                  |                              |  - convert to base currency     |
   |                                  |                              |  - create Request + Items       |
   |                                  |                              |  - Expense -> PENDING_APPROVAL  |
   |                                  |                              |  - AuditLog("SUBMIT")           |
   |  <-- 201 {status: PENDING, ...} |                              |                                |

Manager                          API                          Service layer                      DB
   |  POST /reimbursement-requests/  |                              |                                |
   |    {id}/approve/                |                              |                                |
   |--------------------------------->  ReimbursementRequestViewSet |                                |
   |                                  |----------------------------->  services.approve_request       |
   |                                  |                              |  - assert PENDING + is manager  |
   |                                  |                              |  - Request -> APPROVED          |
   |                                  |                              |  - Expenses -> REIMBURSED       |
   |                                  |                              |  - AuditLog("APPROVE")          |
   |  <-- 200 {status: APPROVED, ...}|                              |                                |
```
