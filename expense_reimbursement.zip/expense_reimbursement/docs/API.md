# API Documentation

Base URL (local dev): `http://127.0.0.1:8000/api/`

Interactive docs (once the server is running): `GET /api/docs/` (Swagger UI,
generated from the live OpenAPI schema at `/api/schema/`). This document is
the hand-written companion reference.

All endpoints (except auth) require an `Authorization: Bearer <access_token>`
header. All request/response bodies are JSON unless noted (receipt upload is
`multipart/form-data`).

---

## Authentication

### `POST /api/auth/register/`
Create a new user. Non-`EMPLOYEE` roles require an authenticated admin caller.

```json
// Request
{
  "username": "employee.jane",
  "password": "S3cure!Pass",
  "first_name": "Jane",
  "last_name": "Doe",
  "email": "jane@example.com",
  "role": "EMPLOYEE",
  "department": 1,
  "manager": 2,
  "home_currency": "USD"
}
```

### `POST /api/auth/token/`
Obtain a JWT access/refresh token pair.
```json
{ "username": "employee.jane", "password": "S3cure!Pass" }
```
→ `{ "access": "...", "refresh": "..." }`

### `POST /api/auth/token/refresh/`
```json
{ "refresh": "..." }
```
→ `{ "access": "..." }`

### `GET /api/auth/me/`
Returns the authenticated user's profile.

---

## Reference data

| Endpoint | Methods | Notes |
|---|---|---|
| `/api/currencies/` | GET | Active currencies (read-only for all authenticated users) |
| `/api/exchange-rates/` | GET, POST, PATCH, DELETE | Admin-managed; GET open to all authenticated users |
| `/api/org-settings/` | GET, PATCH | Singleton; PATCH is admin-only. Holds `base_currency` |
| `/api/departments/` | GET, POST, PATCH, DELETE | Admin-managed; GET open to all |
| `/api/expense-categories/` | GET, POST, PATCH, DELETE | Admin-managed; GET open to all |
| `/api/users/` | GET | Scoped directory: employees see themselves; managers see themselves + direct reports; admins see all |

---

## Expenses

### `GET /api/expenses/`
List expenses visible to the caller (employees: own; managers: own +
direct reports'; admins: all). Supports:

- **Filters** (query params): `category`, `status` (`DRAFT`/`PENDING_APPROVAL`/`REIMBURSED`),
  `currency`, `employee` (manager/admin only, meaningful), `date_from`,
  `date_to` (on `expense_date`), `amount_min`, `amount_max`.
- **Search**: `?search=taxi` (matches `description`, `merchant`).
- **Ordering**: `?ordering=-amount`, `?ordering=expense_date`, etc.
- **Pagination**: `?page=2&page_size=50`.

Example: `GET /api/expenses/?status=DRAFT&category=1&date_from=2026-07-01&search=uber`

### `POST /api/expenses/`
Create a new (DRAFT) expense.
```json
{
  "category": 1,
  "amount": "45.90",
  "currency": "USD",
  "expense_date": "2026-07-20",
  "merchant": "Uber",
  "description": "Airport to client office"
}
```
Validation: `amount > 0`, `expense_date` not in the future, `category` and
`currency` must reference existing active records.

### `GET /api/expenses/{id}/` · `PATCH /api/expenses/{id}/` · `DELETE /api/expenses/{id}/`
Retrieve / edit / soft-delete an expense. **Edit and delete only succeed
while `status == DRAFT`** — once an expense is attached to a submitted
request it's locked (`400 DomainError`: *"This expense cannot be
modified..."*). Delete is a soft-delete (`is_deleted=True`); the row
remains for audit purposes but is excluded from all list/detail queries.

### `POST /api/expenses/{id}/receipts/` (multipart/form-data)
Attach a receipt. Field: `file`. Allowed types: pdf, jpg, jpeg, png; max 5MB.
Only allowed while the expense is `DRAFT`.

### `DELETE /api/expenses/{id}/receipts/{receipt_id}/`
Remove a receipt (DRAFT expenses only).

### `GET /api/expenses/{id}/audit/`
Full audit history for this expense (create/update/delete/receipt events).

---

## Reimbursement Requests

A request bundles one or more of the employee's own `DRAFT` expenses.
Submitting locks those expenses (`PENDING_APPROVAL`) and converts each to
the org's base currency, snapshotting the rate used.

### `POST /api/reimbursement-requests/`
```json
{ "expense_ids": [12, 13], "note": "July client travel" }
```
- Only the expenses' owner may submit them (`403` otherwise).
- All `expense_ids` must currently be `DRAFT` and not soft-deleted, or the
  call fails with `400` (`"Expense #13 is already part of an active or
  completed reimbursement request."`) — this is the duplicate-submission
  guard.
- Response: `201` with the full request detail, including the converted
  `total_amount` in the org base currency.

### `GET /api/reimbursement-requests/`
List requests visible to the caller.
- Employees: their own requests.
- Managers: requests they're assigned to decide, their direct reports'
  requests, and their own (if they also submit expenses). Add
  `?scope=department` to additionally see (read-only) every request in
  their department, for reporting purposes.
- Admins: all requests.

Filters: `status`, `employee`, `manager`, `department`, `date_from`/`date_to`
(on `submitted_at`). Search: `?search=...` (employee name/note). Ordering:
`?ordering=-total_amount`, etc.

### `GET /api/reimbursement-requests/{id}/`
Full detail: line items (with original + converted amounts and the FX rate
used), comments, employee note, decision timestamps.

### `POST /api/reimbursement-requests/{id}/approve/`
Manager/admin only; must be the employee's assigned manager (or an admin).
```json
{ "comment": "Approved, thanks!" }
```
- Fails `409` if the request isn't `PENDING`.
- Fails `403` if the caller isn't the assigned manager/admin.
- On success: request → `APPROVED`, all its expenses → `REIMBURSED`.

### `POST /api/reimbursement-requests/{id}/reject/`
```json
{ "comment": "Missing receipt for line 2 — please resubmit." }
```
`comment` is **required**. On success: request → `REJECTED`, all its
expenses revert to `DRAFT` so the employee can fix and resubmit them.

### `POST /api/reimbursement-requests/{id}/cancel/`
Employee (owner) only, only while `PENDING`. Reverts expenses to `DRAFT`.

### `GET /api/reimbursement-requests/{id}/comments/` · `POST .../comments/`
```json
{ "message": "Adding the missing receipt now." }
```
Either the request's employee, its assigned manager, or an admin may post.

### `GET /api/reimbursement-requests/{id}/audit/`
Full audit history (submit/approve/reject/cancel/comment events).

### `GET /api/reimbursement-requests/summary/`
Manager/admin only. Departmental summary of **approved** reimbursements in
the org base currency.

Query params: `department` (id), `date_from`, `date_to` (on `decided_at`).
A manager without `?department=` gets their own department only; an admin
without it gets every department.

```json
{
  "base_currency": "USD",
  "overall_total_amount": "18450.00",
  "overall_request_count": 37,
  "by_department": [
    {"employee__department__id": 1, "employee__department__name": "Engineering", "total_amount": "12000.00", "request_count": 22}
  ],
  "by_employee": [
    {"employee__id": 5, "employee__first_name": "Priya", "employee__last_name": "Sharma", "total_amount": "3400.00", "request_count": 6}
  ]
}
```

---

## Error format

```json
{ "detail": "This expense cannot be modified because it is not in DRAFT status..." }
```
or, for field-level validation errors:
```json
{
  "detail": "Validation failed.",
  "errors": { "amount": ["Amount must be greater than zero."] }
}
```

| Status | Meaning |
|---|---|
| 400 | Validation error / business rule violation (e.g. duplicate submission, empty comment) |
| 403 | Not authorized for this object/action |
| 404 | Not found (or not visible to the caller) |
| 409 | Invalid state transition (e.g. approving an already-decided request) |

---

## Example end-to-end flow (curl)

```bash
# 1. Log in
TOKEN=$(curl -s -X POST localhost:8000/api/auth/token/ \
  -d '{"username":"employee.priya","password":"Employee@12345"}' \
  -H 'Content-Type: application/json' | python3 -c "import sys,json;print(json.load(sys.stdin)['access'])")

# 2. Record an expense
curl -s -X POST localhost:8000/api/expenses/ \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"category":1,"amount":"500.00","currency":"INR","expense_date":"2026-07-28","description":"Taxi"}'

# 3. Submit it for reimbursement
curl -s -X POST localhost:8000/api/reimbursement-requests/ \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"expense_ids":[1],"note":"July travel"}'

# 4. Manager approves
MTOKEN=$(curl -s -X POST localhost:8000/api/auth/token/ \
  -d '{"username":"manager.eng","password":"Manager@12345"}' \
  -H 'Content-Type: application/json' | python3 -c "import sys,json;print(json.load(sys.stdin)['access'])")

curl -s -X POST localhost:8000/api/reimbursement-requests/1/approve/ \
  -H "Authorization: Bearer $MTOKEN" -H 'Content-Type: application/json' \
  -d '{"comment":"Approved"}'
```
