from rest_framework.routers import DefaultRouter

from apps.common.views import CurrencyListView, ExchangeRateViewSet, OrganizationSettingsView
from django.urls import path

router = DefaultRouter()
router.register(r"exchange-rates", ExchangeRateViewSet, basename="exchange-rate")

urlpatterns = [
    path("currencies/", CurrencyListView.as_view(), name="currency-list"),
    path("org-settings/", OrganizationSettingsView.as_view(), name="org-settings"),
] + router.urls
