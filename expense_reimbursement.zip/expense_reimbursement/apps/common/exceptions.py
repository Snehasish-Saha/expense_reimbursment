import logging

from django.core.exceptions import PermissionDenied as DjangoPermissionDenied
from django.core.exceptions import ValidationError as DjangoValidationError
from django.http import Http404
from rest_framework import exceptions as drf_exceptions
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import exception_handler as drf_default_handler

logger = logging.getLogger(__name__)


class DomainError(Exception):
    """Base class for business-rule violations raised from the service layer."""

    default_message = "The request could not be completed."
    status_code = status.HTTP_400_BAD_REQUEST

    def __init__(self, message: str | None = None):
        self.message = message or self.default_message
        super().__init__(self.message)


class DuplicateRequestError(DomainError):
    default_message = "One or more expenses are already part of an active reimbursement request."


class InvalidStateTransitionError(DomainError):
    default_message = "This action is not valid for the current status."
    status_code = status.HTTP_409_CONFLICT


class NotOwnerError(DomainError):
    default_message = "You do not have permission to act on this resource."
    status_code = status.HTTP_403_FORBIDDEN


def custom_exception_handler(exc, context):
    """
    Normalizes every error response into:
        {"detail": "...", "errors": {...optional field errors...}}
    and translates our internal DomainError family (raised by the service
    layer) into proper HTTP responses instead of leaking as 500s.
    """
    if isinstance(exc, DomainError):
        return Response({"detail": exc.message}, status=exc.status_code)

    if isinstance(exc, DjangoValidationError):
        exc = drf_exceptions.ValidationError(exc.message_dict if hasattr(exc, "message_dict") else exc.messages)

    if isinstance(exc, DjangoPermissionDenied):
        exc = drf_exceptions.PermissionDenied(str(exc))

    if isinstance(exc, Http404):
        exc = drf_exceptions.NotFound()

    response = drf_default_handler(exc, context)

    if response is not None:
        if isinstance(response.data, dict) and "detail" in response.data and len(response.data) == 1:
            return response
        # Field-level validation errors: keep them under "errors", add a
        # human readable top-level "detail" for clients that only read that.
        response.data = {"detail": "Validation failed.", "errors": response.data}
        return response

    logger.exception("Unhandled exception", exc_info=exc)
    return Response({"detail": "An unexpected error occurred."}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
