"""Shared helpers for building a minimal valid domain graph in tests."""
from datetime import date
from decimal import Decimal

from apps.accounts.models import Department, User
from apps.common.models import Currency, ExchangeRate, OrganizationSettings
from apps.expenses.models import ExpenseCategory


def make_currencies():
    usd, _ = Currency.objects.get_or_create(code="USD", defaults={"name": "US Dollar", "symbol": "$"})
    inr, _ = Currency.objects.get_or_create(code="INR", defaults={"name": "Indian Rupee", "symbol": "₹"})
    ExchangeRate.objects.get_or_create(
        from_currency=inr, to_currency=usd, effective_date=date.today(), defaults={"rate": Decimal("0.012")}
    )
    OrganizationSettings.objects.update_or_create(pk=1, defaults={"base_currency": usd})
    return usd, inr


def make_department(name="Engineering", code="ENG"):
    return Department.objects.create(name=name, code=code)


def make_manager(department, username="manager1"):
    return User.objects.create_user(
        username=username, password="pass12345", role=User.Role.MANAGER, department=department
    )


def make_employee(department, manager, username="employee1", currency_code="INR"):
    return User.objects.create_user(
        username=username,
        password="pass12345",
        role=User.Role.EMPLOYEE,
        department=department,
        manager=manager,
        home_currency_id=currency_code,
    )


def make_category(name="Travel"):
    return ExpenseCategory.objects.create(name=name)
