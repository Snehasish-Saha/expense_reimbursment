from django.conf import settings
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.core.exceptions import ValidationError
from django.db import models


class TimeStampedModel(models.Model):
    """Abstract base providing created/updated timestamps for every domain model."""

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class Currency(models.Model):
    """
    Reference table of supported ISO-4217 currencies.

    Kept as a first-class model (rather than a free-text field) so that
    amounts and exchange rates are always relatable to a known, valid
    currency, and so new currencies can be enabled/disabled centrally.
    """

    code = models.CharField(max_length=3, primary_key=True, help_text="ISO 4217 code, e.g. USD, INR, EUR")
    name = models.CharField(max_length=64)
    symbol = models.CharField(max_length=8, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name_plural = "currencies"
        ordering = ["code"]

    def __str__(self):
        return self.code

    def save(self, *args, **kwargs):
        self.code = self.code.upper()
        super().save(*args, **kwargs)


class ExchangeRate(models.Model):
    """
    Point-in-time FX rate: 1 unit of `from_currency` == `rate` units of `to_currency`.

    Rates are versioned by `effective_date` rather than overwritten, which lets
    us look up "the rate that applied when this expense was submitted" for a
    fully reproducible audit trail, instead of a single mutable "current rate".

    In this reference implementation rates are seeded/maintained manually
    (management command / admin). A production system would sync these from
    a live FX-rate provider on a schedule -- see README "Improvements".
    """

    from_currency = models.ForeignKey(Currency, related_name="rates_from", on_delete=models.PROTECT)
    to_currency = models.ForeignKey(Currency, related_name="rates_to", on_delete=models.PROTECT)
    rate = models.DecimalField(max_digits=18, decimal_places=8)
    effective_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("from_currency", "to_currency", "effective_date")
        ordering = ["-effective_date"]
        indexes = [models.Index(fields=["from_currency", "to_currency", "effective_date"])]

    def __str__(self):
        return f"{self.from_currency_id}->{self.to_currency_id} @ {self.effective_date}: {self.rate}"

    def clean(self):
        if self.from_currency_id and self.to_currency_id and self.from_currency_id == self.to_currency_id:
            raise ValidationError("from_currency and to_currency must differ.")
        if self.rate is not None and self.rate <= 0:
            raise ValidationError("Exchange rate must be positive.")


class OrganizationSettings(models.Model):
    """
    Singleton row holding org-wide configuration, notably the reporting /
    base currency that reimbursement totals and departmental summaries are
    expressed in. Modeled as a table (not a Django setting) so it can be
    changed at runtime by an admin without a deployment.
    """

    base_currency = models.ForeignKey(Currency, on_delete=models.PROTECT, related_name="+")
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name_plural = "organization settings"

    def save(self, *args, **kwargs):
        self.pk = 1  # enforce singleton
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise ValidationError("OrganizationSettings cannot be deleted.")

    @classmethod
    def get_solo(cls):
        obj, _ = cls.objects.get_or_create(
            pk=1,
            defaults={"base_currency_id": settings.DEFAULT_BASE_CURRENCY},
        )
        return obj

    def __str__(self):
        return f"OrganizationSettings(base_currency={self.base_currency_id})"


class AuditLog(models.Model):
    """
    Append-only audit trail. Every meaningful state change in the domain
    (expense created/edited/deleted, request submitted/approved/rejected,
    comment added, ...) writes one row here via AuditService.log(), rather
    than relying solely on model `updated_at` timestamps, so reviewers and
    compliance can reconstruct the full history of any object.

    Uses a GenericForeignKey so a single table can audit Expenses,
    ReimbursementRequests, etc. without per-model audit tables.
    """

    class Action(models.TextChoices):
        CREATE = "CREATE", "Create"
        UPDATE = "UPDATE", "Update"
        DELETE = "DELETE", "Delete"
        SUBMIT = "SUBMIT", "Submit"
        APPROVE = "APPROVE", "Approve"
        REJECT = "REJECT", "Reject"
        CANCEL = "CANCEL", "Cancel"
        COMMENT = "COMMENT", "Comment"
        RECEIPT_UPLOAD = "RECEIPT_UPLOAD", "Receipt Upload"
        RECEIPT_DELETE = "RECEIPT_DELETE", "Receipt Delete"

    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="audit_logs"
    )
    action = models.CharField(max_length=32, choices=Action.choices)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveBigIntegerField()
    target = GenericForeignKey("content_type", "object_id")
    changes = models.JSONField(default=dict, blank=True, help_text="Diff / metadata describing what changed")
    timestamp = models.DateTimeField(auto_now_add=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)

    class Meta:
        ordering = ["-timestamp"]
        indexes = [models.Index(fields=["content_type", "object_id"])]

    def __str__(self):
        return f"{self.timestamp:%Y-%m-%d %H:%M} {self.actor} {self.action} {self.content_type}#{self.object_id}"
