class AuditRequestMiddleware:
    """
    Placeholder middleware kept as an explicit extension point.

    Currently the request object itself is threaded through to
    AuditService.log(..., request=request) from the views/services that need
    IP capture, which is sufficient for this project. If we later want
    automatic, view-agnostic audit capture (e.g. for every mutating
    request), this is the seam to implement it in via thread-local storage.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        return self.get_response(request)
