"""
Cross-cutting services shared by the expenses & reimbursements apps.
Keeping this logic out of models/views keeps the domain layer testable
and gives us one place to swap implementations (e.g. a live FX provider).
"""
from datetime import date
from decimal import Decimal, ROUND_HALF_UP

from django.contrib.contenttypes.models import ContentType

from apps.common.models import AuditLog, ExchangeRate


class CurrencyConversionError(Exception):
    """Raised when no exchange rate is available for the requested conversion."""


class CurrencyConverter:
    """Encapsulates all FX-rate lookup & conversion logic."""

    @staticmethod
    def get_rate(from_code: str, to_code: str, on_date: date | None = None) -> Decimal:
        on_date = on_date or date.today()

        if from_code == to_code:
            return Decimal("1.0")

        # Prefer a direct rate effective on/before the requested date.
        direct = (
            ExchangeRate.objects.filter(
                from_currency_id=from_code, to_currency_id=to_code, effective_date__lte=on_date
            )
            .order_by("-effective_date")
            .first()
        )
        if direct:
            return direct.rate

        # Fall back to the inverse rate if only that direction is stored.
        inverse = (
            ExchangeRate.objects.filter(
                from_currency_id=to_code, to_currency_id=from_code, effective_date__lte=on_date
            )
            .order_by("-effective_date")
            .first()
        )
        if inverse and inverse.rate:
            return Decimal("1.0") / inverse.rate

        raise CurrencyConversionError(
            f"No exchange rate available for {from_code}->{to_code} on or before {on_date}."
        )

    @classmethod
    def convert(cls, amount: Decimal, from_code: str, to_code: str, on_date: date | None = None):
        """
        Returns (converted_amount, rate_used) as a tuple so callers can persist
        both the converted figure and the exact rate applied, for audit purposes.
        """
        rate = cls.get_rate(from_code, to_code, on_date)
        converted = (Decimal(amount) * rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        return converted, rate


class AuditService:
    """Writes immutable audit trail entries for domain events."""

    @staticmethod
    def log(actor, action, target, changes=None, request=None):
        ip_address = None
        if request is not None:
            ip_address = request.META.get("REMOTE_ADDR")

        return AuditLog.objects.create(
            actor=actor if getattr(actor, "is_authenticated", False) else None,
            action=action,
            content_type=ContentType.objects.get_for_model(target.__class__),
            object_id=target.pk,
            changes=changes or {},
            ip_address=ip_address,
        )

    @staticmethod
    def history_for(obj):
        return AuditLog.objects.filter(
            content_type=ContentType.objects.get_for_model(obj.__class__), object_id=obj.pk
        ).select_related("actor")
