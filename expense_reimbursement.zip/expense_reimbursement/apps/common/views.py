from rest_framework import generics, permissions, viewsets
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.models import Currency, ExchangeRate, OrganizationSettings
from apps.common.permissions import IsAdmin
from apps.common.serializers import (
    CurrencySerializer,
    ExchangeRateSerializer,
    OrganizationSettingsSerializer,
)


class CurrencyListView(generics.ListAPIView):
    """Read-only reference list of currencies available to the platform."""

    queryset = Currency.objects.filter(is_active=True)
    serializer_class = CurrencySerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = None


class ExchangeRateViewSet(viewsets.ModelViewSet):
    """
    Admin-managed FX rate table. Employees/managers only need conversions
    (handled server-side during submission/summary endpoints); only admins
    manage the underlying rates.
    """

    queryset = ExchangeRate.objects.select_related("from_currency", "to_currency").all()
    serializer_class = ExchangeRateSerializer

    def get_permissions(self):
        if self.request.method in permissions.SAFE_METHODS:
            return [permissions.IsAuthenticated()]
        return [IsAdmin()]


class OrganizationSettingsView(APIView):
    """Get/update the singleton org settings (base reporting currency)."""

    def get_permissions(self):
        if self.request.method in permissions.SAFE_METHODS:
            return [permissions.IsAuthenticated()]
        return [IsAdmin()]

    def get(self, request):
        obj = OrganizationSettings.get_solo()
        return Response(OrganizationSettingsSerializer(obj).data)

    def patch(self, request):
        obj = OrganizationSettings.get_solo()
        serializer = OrganizationSettingsSerializer(obj, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)
