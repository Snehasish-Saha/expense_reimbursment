from rest_framework.permissions import BasePermission, SAFE_METHODS


class IsEmployee(BasePermission):
    message = "This action requires an employee account."

    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_employee)


class IsManagerOrAdmin(BasePermission):
    message = "This action requires a manager or admin account."

    def has_permission(self, request, view):
        return bool(
            request.user
            and request.user.is_authenticated
            and (request.user.is_manager or request.user.is_admin_role)
        )


class IsAdmin(BasePermission):
    message = "This action requires an administrator account."

    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_admin_role)


class ReadOnly(BasePermission):
    def has_permission(self, request, view):
        return request.method in SAFE_METHODS
