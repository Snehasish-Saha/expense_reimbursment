"""
Seeds a small, coherent demo dataset so the API can be exercised end-to-end
immediately after `migrate`:

- Currencies + a couple of illustrative exchange rates
- Org settings (base currency = USD)
- Two departments, an admin, two managers, four employees
- Expense categories
- A handful of sample expenses in different currencies/statuses

Usage: python manage.py seed_demo_data
Idempotent: safe to re-run (uses get_or_create throughout).
"""
from datetime import date, timedelta
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db import transaction

from apps.accounts.models import Department, User
from apps.common.models import Currency, ExchangeRate, OrganizationSettings
from apps.expenses.models import Expense, ExpenseCategory


class Command(BaseCommand):
    help = "Seed demo data (currencies, org settings, departments, users, categories, sample expenses)."

    @transaction.atomic
    def handle(self, *args, **options):
        self.stdout.write("Seeding currencies...")
        currencies = {
            "USD": ("US Dollar", "$"),
            "EUR": ("Euro", "€"),
            "GBP": ("British Pound", "£"),
            "INR": ("Indian Rupee", "₹"),
        }
        for code, (name, symbol) in currencies.items():
            Currency.objects.get_or_create(code=code, defaults={"name": name, "symbol": symbol})

        self.stdout.write("Seeding exchange rates (effective today)...")
        today = date.today()
        rates = [
            ("EUR", "USD", Decimal("1.08")),
            ("GBP", "USD", Decimal("1.27")),
            ("INR", "USD", Decimal("0.012")),
        ]
        for from_code, to_code, rate in rates:
            ExchangeRate.objects.get_or_create(
                from_currency_id=from_code,
                to_currency_id=to_code,
                effective_date=today,
                defaults={"rate": rate},
            )

        self.stdout.write("Setting org base currency to USD...")
        org_settings = OrganizationSettings.get_solo()
        if org_settings.base_currency_id != "USD":
            org_settings.base_currency_id = "USD"
            org_settings.save()

        self.stdout.write("Seeding departments...")
        engineering, _ = Department.objects.get_or_create(name="Engineering", code="ENG")
        sales, _ = Department.objects.get_or_create(name="Sales", code="SLS")

        self.stdout.write("Seeding users...")
        admin_user, created = User.objects.get_or_create(
            username="admin",
            defaults=dict(email="admin@example.com", role=User.Role.ADMIN, is_staff=True, is_superuser=True),
        )
        if created:
            admin_user.set_password("Admin@12345")
            admin_user.save()

        manager_eng, created = User.objects.get_or_create(
            username="manager.eng",
            defaults=dict(
                email="manager.eng@example.com",
                first_name="Maya",
                last_name="Chen",
                role=User.Role.MANAGER,
                department=engineering,
                home_currency_id="USD",
            ),
        )
        if created:
            manager_eng.set_password("Manager@12345")
            manager_eng.save()

        manager_sales, created = User.objects.get_or_create(
            username="manager.sales",
            defaults=dict(
                email="manager.sales@example.com",
                first_name="Sam",
                last_name="Diallo",
                role=User.Role.MANAGER,
                department=sales,
                home_currency_id="GBP",
            ),
        )
        if created:
            manager_sales.set_password("Manager@12345")
            manager_sales.save()

        employees_spec = [
            ("employee.priya", "Priya", "Sharma", engineering, manager_eng, "INR"),
            ("employee.diego", "Diego", "Alvarez", engineering, manager_eng, "EUR"),
            ("employee.lucy", "Lucy", "Watson", sales, manager_sales, "GBP"),
            ("employee.tom", "Tom", "Baker", sales, manager_sales, "USD"),
        ]
        employees = []
        for username, first, last, dept, manager, currency in employees_spec:
            user, created = User.objects.get_or_create(
                username=username,
                defaults=dict(
                    email=f"{username}@example.com",
                    first_name=first,
                    last_name=last,
                    role=User.Role.EMPLOYEE,
                    department=dept,
                    manager=manager,
                    home_currency_id=currency,
                ),
            )
            if created:
                user.set_password("Employee@12345")
                user.save()
            employees.append(user)

        self.stdout.write("Seeding expense categories...")
        category_names = ["Travel", "Meals & Entertainment", "Office Supplies", "Software & Subscriptions", "Lodging"]
        categories = {}
        for name in category_names:
            cat, _ = ExpenseCategory.objects.get_or_create(name=name)
            categories[name] = cat

        self.stdout.write("Seeding a few sample DRAFT expenses...")
        priya = employees[0]
        Expense.objects.get_or_create(
            employee=priya,
            category=categories["Travel"],
            amount=Decimal("2400.00"),
            currency_id="INR",
            expense_date=today - timedelta(days=3),
            defaults=dict(merchant="Ola Cabs", description="Client site visit taxi fare"),
        )
        Expense.objects.get_or_create(
            employee=priya,
            category=categories["Meals & Entertainment"],
            amount=Decimal("650.00"),
            currency_id="INR",
            expense_date=today - timedelta(days=2),
            defaults=dict(merchant="Cafe Coffee Day", description="Team lunch with client"),
        )

        self.stdout.write(self.style.SUCCESS("Demo data seeded successfully."))
        self.stdout.write(
            "Login credentials -> admin/Admin@12345, manager.eng/Manager@12345, "
            "manager.sales/Manager@12345, employee.priya/Employee@12345 (etc.)"
        )
