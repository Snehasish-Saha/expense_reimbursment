from rest_framework import serializers

from apps.common.models import AuditLog, Currency, ExchangeRate, OrganizationSettings


class CurrencySerializer(serializers.ModelSerializer):
    class Meta:
        model = Currency
        fields = ["code", "name", "symbol", "is_active"]


class ExchangeRateSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExchangeRate
        fields = ["id", "from_currency", "to_currency", "rate", "effective_date", "created_at"]
        read_only_fields = ["id", "created_at"]

    def validate(self, attrs):
        from_c = attrs.get("from_currency") or getattr(self.instance, "from_currency", None)
        to_c = attrs.get("to_currency") or getattr(self.instance, "to_currency", None)
        if from_c and to_c and from_c == to_c:
            raise serializers.ValidationError("from_currency and to_currency must differ.")
        if attrs.get("rate") is not None and attrs["rate"] <= 0:
            raise serializers.ValidationError("rate must be positive.")
        return attrs


class OrganizationSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrganizationSettings
        fields = ["base_currency", "updated_at"]
        read_only_fields = ["updated_at"]


class AuditLogSerializer(serializers.ModelSerializer):
    actor_username = serializers.CharField(source="actor.username", read_only=True, default=None)
    content_type = serializers.CharField(source="content_type.model", read_only=True)

    class Meta:
        model = AuditLog
        fields = [
            "id",
            "actor",
            "actor_username",
            "action",
            "content_type",
            "object_id",
            "changes",
            "timestamp",
            "ip_address",
        ]
        read_only_fields = fields
