from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers

from apps.accounts.models import Department, User


class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ["id", "name", "code"]


class UserSerializer(serializers.ModelSerializer):
    department_name = serializers.CharField(source="department.name", read_only=True, default=None)
    manager_name = serializers.CharField(source="manager.get_full_name", read_only=True, default=None)

    class Meta:
        model = User
        fields = [
            "id",
            "username",
            "first_name",
            "last_name",
            "email",
            "role",
            "department",
            "department_name",
            "manager",
            "manager_name",
            "home_currency",
            "is_active",
        ]
        read_only_fields = ["id"]


class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, validators=[validate_password])

    class Meta:
        model = User
        fields = [
            "id",
            "username",
            "password",
            "first_name",
            "last_name",
            "email",
            "role",
            "department",
            "manager",
            "home_currency",
        ]

    def validate(self, attrs):
        role = attrs.get("role", User.Role.EMPLOYEE)
        manager = attrs.get("manager")
        if role == User.Role.EMPLOYEE and manager is None:
            # Not a hard requirement (an employee could be unassigned
            # temporarily), but we surface it clearly since an employee
            # without a manager cannot get their requests approved.
            pass
        if manager and role != User.Role.EMPLOYEE and manager.role != User.Role.MANAGER:
            raise serializers.ValidationError({"manager": "Assigned manager must have the MANAGER role."})
        return attrs

    def create(self, validated_data):
        password = validated_data.pop("password")
        user = User(**validated_data)
        user.set_password(password)
        user.full_clean(exclude=["password"])
        user.save()
        return user
