from django.db.models import Q
from rest_framework import generics, permissions, viewsets
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.models import Department, User
from apps.accounts.serializers import (
    DepartmentSerializer,
    UserRegistrationSerializer,
    UserSerializer,
)
from apps.common.permissions import IsAdmin


class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer

    def get_permissions(self):
        if self.request.method in permissions.SAFE_METHODS:
            return [permissions.IsAuthenticated()]
        return [IsAdmin()]


class RegisterView(generics.CreateAPIView):
    """
    Open registration for demo purposes. In a real deployment this would be
    replaced by admin-provisioned accounts / SSO, and role escalation
    (creating MANAGER/ADMIN accounts) would be admin-only. We approximate
    that here by requiring IsAdmin to self-register anything but EMPLOYEE.
    """

    serializer_class = UserRegistrationSerializer
    permission_classes = [permissions.AllowAny]

    def create(self, request, *args, **kwargs):
        requested_role = request.data.get("role", User.Role.EMPLOYEE)
        if requested_role != User.Role.EMPLOYEE:
            if not (request.user.is_authenticated and request.user.is_admin_role):
                return Response(
                    {"detail": "Only an admin can create MANAGER or ADMIN accounts."}, status=403
                )
        return super().create(request, *args, **kwargs)


class MeView(APIView):
    """Returns the profile of the currently authenticated user."""

    def get(self, request):
        return Response(UserSerializer(request.user).data)


class UserViewSet(viewsets.ReadOnlyModelViewSet):
    """
    Read-only directory, primarily so managers/admins can look up employees
    (e.g. to pick expense owners while filtering). Employees can only see
    themselves and their manager.
    """

    serializer_class = UserSerializer

    def get_queryset(self):
        user = self.request.user
        qs = User.objects.select_related("department", "manager")
        if user.is_admin_role:
            return qs
        if user.is_manager:
            return qs.filter(Q(id=user.id) | Q(manager_id=user.id))
        return qs.filter(id=user.id)
