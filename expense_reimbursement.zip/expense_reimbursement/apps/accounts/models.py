from django.contrib.auth.models import AbstractUser
from django.core.exceptions import ValidationError
from django.db import models


class Department(models.Model):
    name = models.CharField(max_length=100, unique=True)
    code = models.CharField(max_length=20, unique=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class User(AbstractUser):
    """
    Extends the default Django user with the fields needed for the
    reimbursement workflow:

    - role: drives permissioning (see apps.common.permissions).
    - department: used for departmental summaries/reporting.
    - manager: the direct approver for this user's reimbursement requests.
      Kept as an explicit FK (rather than inferring "manager" from
      department headship) so approval routing is unambiguous even if a
      department has multiple managers.
    - home_currency: default currency pre-filled on new expenses for this
      user; reflects "the employee may be located in a different country
      than the employer".
    """

    class Role(models.TextChoices):
        EMPLOYEE = "EMPLOYEE", "Employee"
        MANAGER = "MANAGER", "Manager"
        ADMIN = "ADMIN", "Admin"

    role = models.CharField(max_length=16, choices=Role.choices, default=Role.EMPLOYEE)
    department = models.ForeignKey(
        Department, null=True, blank=True, on_delete=models.SET_NULL, related_name="members"
    )
    manager = models.ForeignKey(
        "self", null=True, blank=True, on_delete=models.SET_NULL, related_name="direct_reports"
    )
    home_currency = models.ForeignKey(
        "common.Currency", null=True, blank=True, on_delete=models.SET_NULL, related_name="+"
    )

    @property
    def is_employee(self):
        return self.role == self.Role.EMPLOYEE

    @property
    def is_manager(self):
        return self.role == self.Role.MANAGER

    @property
    def is_admin_role(self):
        return self.role == self.Role.ADMIN or self.is_superuser

    def clean(self):
        if self.manager_id and self.manager_id == self.id:
            raise ValidationError("A user cannot be their own manager.")

    def __str__(self):
        return self.get_full_name() or self.username
