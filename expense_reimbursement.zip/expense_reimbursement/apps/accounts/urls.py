from django.urls import path
from rest_framework.routers import DefaultRouter

from apps.accounts.views import DepartmentViewSet, MeView, RegisterView, UserViewSet

router = DefaultRouter()
router.register(r"departments", DepartmentViewSet, basename="department")
router.register(r"users", UserViewSet, basename="user")

urlpatterns = [
    path("auth/register/", RegisterView.as_view(), name="register"),
    path("auth/me/", MeView.as_view(), name="me"),
] + router.urls
