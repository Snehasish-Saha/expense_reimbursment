from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin

from apps.accounts.models import Department, User


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ("name", "code")
    search_fields = ("name", "code")


@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    fieldsets = DjangoUserAdmin.fieldsets + (
        ("Reimbursement platform", {"fields": ("role", "department", "manager", "home_currency")}),
    )
    list_display = ("username", "email", "role", "department", "manager", "is_active")
    list_filter = ("role", "department", "is_active")
