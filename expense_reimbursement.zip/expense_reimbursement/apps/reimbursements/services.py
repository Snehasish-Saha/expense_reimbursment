"""
Service layer for the reimbursement approval workflow.

Keeping state-transition logic here (rather than spreading it across
views/serializers) means:
  * the rules that matter most for correctness ("can't submit someone
    else's expense", "can't double-claim an expense", "only a PENDING
    request can be approved") live in one place and are unit-testable
    without HTTP.
  * every transition writes an AuditLog entry, so the audit trail can't be
    accidentally skipped by a future new API endpoint that forgets to.
"""
from datetime import date

from django.db import transaction
from django.utils import timezone

from apps.common.exceptions import DomainError, DuplicateRequestError, InvalidStateTransitionError, NotOwnerError
from apps.common.models import OrganizationSettings
from apps.common.services import AuditService, CurrencyConversionError, CurrencyConverter
from apps.expenses.models import Expense
from apps.reimbursements.models import ReimbursementRequest, ReimbursementRequestItem, RequestComment


@transaction.atomic
def submit_request(*, employee, expense_ids, note="", request=None):
    if not expense_ids:
        raise DomainError("At least one expense must be included in a reimbursement request.")

    unique_ids = list(dict.fromkeys(expense_ids))  # de-dupe while preserving order
    if len(unique_ids) != len(expense_ids):
        raise DomainError("Duplicate expense IDs were supplied in the same request.")

    # Lock the candidate expense rows so two concurrent submissions can't
    # both grab the same DRAFT expense (classic double-submit race).
    expenses = list(
        Expense.objects.select_for_update()
        .filter(id__in=unique_ids, is_deleted=False)
        .select_related("currency")
    )
    found_ids = {e.id for e in expenses}
    missing = set(unique_ids) - found_ids
    if missing:
        raise DomainError(f"Expense(s) not found: {sorted(missing)}")

    for expense in expenses:
        if expense.employee_id != employee.id:
            raise NotOwnerError("You can only submit your own expenses for reimbursement.")
        if expense.status != Expense.Status.DRAFT:
            raise DuplicateRequestError(
                f"Expense #{expense.id} is already part of an active or completed reimbursement request."
            )

    org_settings = OrganizationSettings.get_solo()
    base_currency = org_settings.base_currency

    reimbursement_request = ReimbursementRequest.objects.create(
        employee=employee,
        manager=employee.manager,
        status=ReimbursementRequest.Status.PENDING,
        base_currency=base_currency,
        employee_note=note,
        submitted_at=timezone.now(),
    )

    total = 0
    today = date.today()
    for expense in expenses:
        try:
            converted, rate = CurrencyConverter.convert(
                expense.amount, expense.currency_id, base_currency.code, on_date=today
            )
        except CurrencyConversionError as exc:
            raise DomainError(str(exc)) from exc

        ReimbursementRequestItem.objects.create(
            request=reimbursement_request,
            expense=expense,
            original_amount=expense.amount,
            original_currency=expense.currency,
            exchange_rate_used=rate,
            converted_amount=converted,
        )
        total += converted
        expense.status = Expense.Status.PENDING_APPROVAL
        expense.save(update_fields=["status"])

    reimbursement_request.total_amount = total
    reimbursement_request.save(update_fields=["total_amount"])

    AuditService.log(
        employee,
        "SUBMIT",
        reimbursement_request,
        changes={"expense_ids": unique_ids, "total_amount": str(total), "base_currency": base_currency.code},
        request=request,
    )
    return reimbursement_request


def _assert_can_decide(reimbursement_request, manager):
    if reimbursement_request.status != ReimbursementRequest.Status.PENDING:
        raise InvalidStateTransitionError(
            f"Request is already {reimbursement_request.status}; only PENDING requests can be decided."
        )
    is_direct_manager = reimbursement_request.employee.manager_id == manager.id
    if not (is_direct_manager or manager.is_admin_role):
        raise NotOwnerError("You are not authorized to approve or reject this request.")


@transaction.atomic
def approve_request(*, reimbursement_request, manager, comment="", request=None):
    reimbursement_request = ReimbursementRequest.objects.select_for_update().get(pk=reimbursement_request.pk)
    _assert_can_decide(reimbursement_request, manager)

    reimbursement_request.status = ReimbursementRequest.Status.APPROVED
    reimbursement_request.manager = manager
    reimbursement_request.decided_at = timezone.now()
    reimbursement_request.save(update_fields=["status", "manager", "decided_at"])

    Expense.objects.filter(request_items__request=reimbursement_request).update(status=Expense.Status.REIMBURSED)

    if comment:
        RequestComment.objects.create(request=reimbursement_request, author=manager, message=comment)

    AuditService.log(manager, "APPROVE", reimbursement_request, changes={"comment": comment}, request=request)
    return reimbursement_request


@transaction.atomic
def reject_request(*, reimbursement_request, manager, comment, request=None):
    if not comment:
        raise DomainError("A comment explaining the rejection is required.")

    reimbursement_request = ReimbursementRequest.objects.select_for_update().get(pk=reimbursement_request.pk)
    _assert_can_decide(reimbursement_request, manager)

    reimbursement_request.status = ReimbursementRequest.Status.REJECTED
    reimbursement_request.manager = manager
    reimbursement_request.decided_at = timezone.now()
    reimbursement_request.save(update_fields=["status", "manager", "decided_at"])

    # Revert expenses to DRAFT so the employee can correct and resubmit them.
    Expense.objects.filter(request_items__request=reimbursement_request).update(status=Expense.Status.DRAFT)

    RequestComment.objects.create(request=reimbursement_request, author=manager, message=comment)

    AuditService.log(manager, "REJECT", reimbursement_request, changes={"comment": comment}, request=request)
    return reimbursement_request


@transaction.atomic
def cancel_request(*, reimbursement_request, employee, request=None):
    reimbursement_request = ReimbursementRequest.objects.select_for_update().get(pk=reimbursement_request.pk)

    if reimbursement_request.employee_id != employee.id:
        raise NotOwnerError("You can only cancel your own reimbursement requests.")
    if reimbursement_request.status != ReimbursementRequest.Status.PENDING:
        raise InvalidStateTransitionError("Only PENDING requests can be cancelled.")

    reimbursement_request.status = ReimbursementRequest.Status.CANCELLED
    reimbursement_request.decided_at = timezone.now()
    reimbursement_request.save(update_fields=["status", "decided_at"])

    Expense.objects.filter(request_items__request=reimbursement_request).update(status=Expense.Status.DRAFT)

    AuditService.log(employee, "CANCEL", reimbursement_request, request=request)
    return reimbursement_request


def add_comment(*, reimbursement_request, author, message, request=None):
    if not message or not message.strip():
        raise DomainError("Comment message cannot be empty.")

    is_participant = author.id in (reimbursement_request.employee_id, reimbursement_request.manager_id)
    if not (is_participant or author.is_admin_role):
        raise NotOwnerError("Only the request's employee or manager can comment on it.")

    comment = RequestComment.objects.create(request=reimbursement_request, author=author, message=message.strip())
    AuditService.log(author, "COMMENT", reimbursement_request, changes={"comment_id": comment.id}, request=request)
    return comment
