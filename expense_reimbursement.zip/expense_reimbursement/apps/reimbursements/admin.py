from django.contrib import admin

from apps.reimbursements.models import ReimbursementRequest, ReimbursementRequestItem, RequestComment


class ReimbursementRequestItemInline(admin.TabularInline):
    model = ReimbursementRequestItem
    extra = 0
    readonly_fields = ["expense", "original_amount", "original_currency", "exchange_rate_used", "converted_amount"]


class RequestCommentInline(admin.TabularInline):
    model = RequestComment
    extra = 0
    readonly_fields = ["author", "message", "created_at"]


@admin.register(ReimbursementRequest)
class ReimbursementRequestAdmin(admin.ModelAdmin):
    list_display = ("id", "employee", "manager", "status", "base_currency", "total_amount", "submitted_at", "decided_at")
    list_filter = ("status", "base_currency")
    search_fields = ("employee__username", "employee__first_name", "employee__last_name")
    inlines = [ReimbursementRequestItemInline, RequestCommentInline]
    readonly_fields = ["total_amount", "submitted_at", "decided_at"]
