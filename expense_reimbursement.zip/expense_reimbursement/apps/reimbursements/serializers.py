from rest_framework import serializers

from apps.reimbursements.models import ReimbursementRequest, ReimbursementRequestItem, RequestComment


class RequestCommentSerializer(serializers.ModelSerializer):
    author_name = serializers.CharField(source="author.get_full_name", read_only=True)

    class Meta:
        model = RequestComment
        fields = ["id", "request", "author", "author_name", "message", "created_at"]
        read_only_fields = ["id", "request", "author", "author_name", "created_at"]


class ReimbursementRequestItemSerializer(serializers.ModelSerializer):
    expense_description = serializers.CharField(source="expense.description", read_only=True)
    category = serializers.CharField(source="expense.category.name", read_only=True)

    class Meta:
        model = ReimbursementRequestItem
        fields = [
            "id",
            "expense",
            "expense_description",
            "category",
            "original_amount",
            "original_currency",
            "exchange_rate_used",
            "converted_amount",
        ]
        read_only_fields = fields


class ReimbursementRequestListSerializer(serializers.ModelSerializer):
    employee_name = serializers.CharField(source="employee.get_full_name", read_only=True)
    manager_name = serializers.CharField(source="manager.get_full_name", read_only=True, default=None)
    department = serializers.CharField(source="employee.department.name", read_only=True, default=None)
    item_count = serializers.IntegerField(source="items.count", read_only=True)

    class Meta:
        model = ReimbursementRequest
        fields = [
            "id",
            "employee",
            "employee_name",
            "department",
            "manager",
            "manager_name",
            "status",
            "base_currency",
            "total_amount",
            "item_count",
            "submitted_at",
            "decided_at",
            "created_at",
        ]
        read_only_fields = fields


class ReimbursementRequestDetailSerializer(ReimbursementRequestListSerializer):
    items = ReimbursementRequestItemSerializer(many=True, read_only=True)
    comments = RequestCommentSerializer(many=True, read_only=True)

    class Meta(ReimbursementRequestListSerializer.Meta):
        fields = ReimbursementRequestListSerializer.Meta.fields + ["employee_note", "items", "comments"]
        read_only_fields = fields


class ReimbursementRequestCreateSerializer(serializers.Serializer):
    """Input serializer for POST /reimbursement-requests/ (submit a new batch)."""

    expense_ids = serializers.ListField(child=serializers.IntegerField(), allow_empty=False, min_length=1)
    note = serializers.CharField(required=False, allow_blank=True, default="")


class DecisionSerializer(serializers.Serializer):
    """Input serializer for approve/reject actions."""

    comment = serializers.CharField(required=False, allow_blank=True, default="")


class RejectSerializer(serializers.Serializer):
    comment = serializers.CharField(required=True, allow_blank=False)


class AddCommentSerializer(serializers.Serializer):
    message = serializers.CharField(required=True, allow_blank=False)
