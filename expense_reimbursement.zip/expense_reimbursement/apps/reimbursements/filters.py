import django_filters as df

from apps.reimbursements.models import ReimbursementRequest


class ReimbursementRequestFilter(df.FilterSet):
    status = df.ChoiceFilter(choices=ReimbursementRequest.Status.choices)
    employee = df.NumberFilter(field_name="employee_id")
    manager = df.NumberFilter(field_name="manager_id")
    department = df.NumberFilter(field_name="employee__department_id")
    date_from = df.DateFilter(field_name="submitted_at", lookup_expr="date__gte")
    date_to = df.DateFilter(field_name="submitted_at", lookup_expr="date__lte")

    class Meta:
        model = ReimbursementRequest
        fields = ["status", "employee", "manager", "department", "date_from", "date_to"]
