from rest_framework.routers import DefaultRouter

from apps.reimbursements.views import ReimbursementRequestViewSet

router = DefaultRouter()
router.register(r"reimbursement-requests", ReimbursementRequestViewSet, basename="reimbursement-request")

urlpatterns = router.urls
