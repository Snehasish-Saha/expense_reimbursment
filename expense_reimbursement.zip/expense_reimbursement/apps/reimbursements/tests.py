from datetime import date
from decimal import Decimal

from django.test import TestCase

from apps.common.exceptions import DomainError, DuplicateRequestError, InvalidStateTransitionError, NotOwnerError
from apps.common.test_helpers import make_category, make_currencies, make_department, make_employee, make_manager
from apps.expenses.models import Expense
from apps.reimbursements import services
from apps.reimbursements.models import ReimbursementRequest


class ReimbursementServiceTests(TestCase):
    def setUp(self):
        self.usd, self.inr = make_currencies()
        self.department = make_department()
        self.manager = make_manager(self.department)
        self.other_manager = make_manager(self.department, username="manager2")
        self.employee = make_employee(self.department, self.manager)
        self.category = make_category()

    def _draft_expense(self, amount="500.00", **overrides):
        defaults = dict(
            employee=self.employee,
            category=self.category,
            amount=Decimal(amount),
            currency=self.inr,
            expense_date=date.today(),
            description="Taxi",
        )
        defaults.update(overrides)
        return Expense.objects.create(**defaults)

    def test_submit_request_converts_to_base_currency_and_locks_expenses(self):
        e1 = self._draft_expense("500.00")
        e2 = self._draft_expense("100.00")

        req = services.submit_request(employee=self.employee, expense_ids=[e1.id, e2.id])

        e1.refresh_from_db()
        e2.refresh_from_db()
        self.assertEqual(e1.status, Expense.Status.PENDING_APPROVAL)
        self.assertEqual(e2.status, Expense.Status.PENDING_APPROVAL)
        self.assertEqual(req.status, ReimbursementRequest.Status.PENDING)
        self.assertEqual(req.base_currency_id, "USD")
        # 600 INR * 0.012 = 7.20 USD
        self.assertEqual(req.total_amount, Decimal("7.20"))

    def test_cannot_submit_someone_elses_expense(self):
        other_employee = make_employee(self.department, self.manager, username="employee2", currency_code="INR")
        expense = self._draft_expense(employee=other_employee)
        with self.assertRaises(NotOwnerError):
            services.submit_request(employee=self.employee, expense_ids=[expense.id])

    def test_cannot_double_submit_same_expense(self):
        expense = self._draft_expense()
        services.submit_request(employee=self.employee, expense_ids=[expense.id])
        with self.assertRaises(DuplicateRequestError):
            services.submit_request(employee=self.employee, expense_ids=[expense.id])

    def test_empty_submission_rejected(self):
        with self.assertRaises(DomainError):
            services.submit_request(employee=self.employee, expense_ids=[])

    def test_approve_marks_expenses_reimbursed(self):
        expense = self._draft_expense()
        req = services.submit_request(employee=self.employee, expense_ids=[expense.id])

        result = services.approve_request(reimbursement_request=req, manager=self.manager, comment="Looks good")

        expense.refresh_from_db()
        self.assertEqual(result.status, ReimbursementRequest.Status.APPROVED)
        self.assertEqual(expense.status, Expense.Status.REIMBURSED)

    def test_only_assigned_manager_can_decide(self):
        expense = self._draft_expense()
        req = services.submit_request(employee=self.employee, expense_ids=[expense.id])

        with self.assertRaises(NotOwnerError):
            services.approve_request(reimbursement_request=req, manager=self.other_manager, comment="")

    def test_reject_requires_comment_and_reverts_expense_to_draft(self):
        expense = self._draft_expense()
        req = services.submit_request(employee=self.employee, expense_ids=[expense.id])

        with self.assertRaises(DomainError):
            services.reject_request(reimbursement_request=req, manager=self.manager, comment="")

        result = services.reject_request(reimbursement_request=req, manager=self.manager, comment="Missing receipt")
        expense.refresh_from_db()
        self.assertEqual(result.status, ReimbursementRequest.Status.REJECTED)
        self.assertEqual(expense.status, Expense.Status.DRAFT)

    def test_rejected_expense_can_be_resubmitted(self):
        expense = self._draft_expense()
        req = services.submit_request(employee=self.employee, expense_ids=[expense.id])
        services.reject_request(reimbursement_request=req, manager=self.manager, comment="Fix this")

        # Should succeed now that the expense is back in DRAFT.
        new_req = services.submit_request(employee=self.employee, expense_ids=[expense.id])
        self.assertEqual(new_req.status, ReimbursementRequest.Status.PENDING)

    def test_cannot_decide_already_decided_request(self):
        expense = self._draft_expense()
        req = services.submit_request(employee=self.employee, expense_ids=[expense.id])
        services.approve_request(reimbursement_request=req, manager=self.manager, comment="")

        with self.assertRaises(InvalidStateTransitionError):
            services.approve_request(reimbursement_request=req, manager=self.manager, comment="")

    def test_cancel_only_by_owner_while_pending(self):
        expense = self._draft_expense()
        req = services.submit_request(employee=self.employee, expense_ids=[expense.id])

        with self.assertRaises(NotOwnerError):
            services.cancel_request(reimbursement_request=req, employee=self.other_manager)

        result = services.cancel_request(reimbursement_request=req, employee=self.employee)
        expense.refresh_from_db()
        self.assertEqual(result.status, ReimbursementRequest.Status.CANCELLED)
        self.assertEqual(expense.status, Expense.Status.DRAFT)
