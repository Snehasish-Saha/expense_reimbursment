from django.db.models import Count, Q, Sum
from django.shortcuts import get_object_or_404
from rest_framework import permissions, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.common.exceptions import DomainError
from apps.common.permissions import IsEmployee, IsManagerOrAdmin
from apps.common.serializers import AuditLogSerializer
from apps.common.services import AuditService
from apps.reimbursements import services
from apps.reimbursements.filters import ReimbursementRequestFilter
from apps.reimbursements.models import ReimbursementRequest, RequestComment
from apps.reimbursements.serializers import (
    AddCommentSerializer,
    DecisionSerializer,
    ReimbursementRequestCreateSerializer,
    ReimbursementRequestDetailSerializer,
    ReimbursementRequestListSerializer,
    RejectSerializer,
    RequestCommentSerializer,
)


class ReimbursementRequestViewSet(viewsets.ModelViewSet):
    """
    Employees submit/cancel their own requests; managers approve/reject
    their direct reports' requests and add comments; everyone with
    visibility can browse/filter/search and see the full audit trail.

    `http_method_names` excludes PUT/PATCH/DELETE at the collection level:
    a reimbursement request is not "edited" once submitted -- state moves
    forward only through the explicit approve/reject/cancel actions, which
    keeps the audit trail meaningful (no silent field edits on a request
    that's awaiting a decision).
    """

    filterset_class = ReimbursementRequestFilter
    search_fields = ["employee_note", "employee__first_name", "employee__last_name", "employee__username"]
    ordering_fields = ["submitted_at", "decided_at", "total_amount", "created_at"]
    http_method_names = ["get", "post", "head", "options"]

    def get_serializer_class(self):
        if self.action == "create":
            return ReimbursementRequestCreateSerializer
        if self.action == "list":
            return ReimbursementRequestListSerializer
        return ReimbursementRequestDetailSerializer

    def get_queryset(self):
        user = self.request.user
        qs = ReimbursementRequest.objects.select_related(
            "employee", "employee__department", "manager", "base_currency"
        ).prefetch_related("items", "comments")

        if user.is_admin_role:
            return qs

        if user.is_manager:
            base = Q(manager_id=user.id) | Q(employee__manager_id=user.id) | Q(employee_id=user.id)
            if self.request.query_params.get("scope") == "department" and user.department_id:
                # Read-only wider view for departmental reporting; approval
                # actions are still gated to the assigned manager (see
                # services._assert_can_decide).
                base = base | Q(employee__department_id=user.department_id)
            return qs.filter(base).distinct()

        return qs.filter(employee_id=user.id)

    def get_permissions(self):
        if self.action == "create":
            return [permissions.IsAuthenticated(), IsEmployee()]
        if self.action in ("approve", "reject"):
            return [permissions.IsAuthenticated(), IsManagerOrAdmin()]
        if self.action == "summary":
            return [permissions.IsAuthenticated(), IsManagerOrAdmin()]
        return [permissions.IsAuthenticated()]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            reimbursement_request = services.submit_request(
                employee=request.user,
                expense_ids=serializer.validated_data["expense_ids"],
                note=serializer.validated_data.get("note", ""),
                request=request,
            )
        except DomainError:
            raise
        output = ReimbursementRequestDetailSerializer(reimbursement_request)
        return Response(output.data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def approve(self, request, pk=None):
        reimbursement_request = self.get_object()
        serializer = DecisionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        result = services.approve_request(
            reimbursement_request=reimbursement_request,
            manager=request.user,
            comment=serializer.validated_data.get("comment", ""),
            request=request,
        )
        return Response(ReimbursementRequestDetailSerializer(result).data)

    @action(detail=True, methods=["post"])
    def reject(self, request, pk=None):
        reimbursement_request = self.get_object()
        serializer = RejectSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        result = services.reject_request(
            reimbursement_request=reimbursement_request,
            manager=request.user,
            comment=serializer.validated_data["comment"],
            request=request,
        )
        return Response(ReimbursementRequestDetailSerializer(result).data)

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        reimbursement_request = self.get_object()
        result = services.cancel_request(reimbursement_request=reimbursement_request, employee=request.user, request=request)
        return Response(ReimbursementRequestDetailSerializer(result).data)

    @action(detail=True, methods=["get", "post"], url_path="comments")
    def comments(self, request, pk=None):
        reimbursement_request = self.get_object()
        if request.method == "GET":
            qs = reimbursement_request.comments.select_related("author")
            return Response(RequestCommentSerializer(qs, many=True).data)

        serializer = AddCommentSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        comment = services.add_comment(
            reimbursement_request=reimbursement_request,
            author=request.user,
            message=serializer.validated_data["message"],
            request=request,
        )
        return Response(RequestCommentSerializer(comment).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["get"], url_path="audit")
    def audit_history(self, request, pk=None):
        reimbursement_request = self.get_object()
        history = AuditService.history_for(reimbursement_request)
        return Response(AuditLogSerializer(history, many=True).data)

    @action(detail=False, methods=["get"])
    def summary(self, request):
        """
        Departmental summary of APPROVED reimbursements, in the org base
        currency, optionally scoped by department and date range. Powers
        the "Managers should be able to view ... departmental summaries"
        requirement.
        """
        user = request.user
        qs = ReimbursementRequest.objects.filter(status=ReimbursementRequest.Status.APPROVED)

        if not user.is_admin_role:
            # A manager only gets summaries for their own department by default.
            qs = qs.filter(employee__department_id=user.department_id)

        department_id = request.query_params.get("department")
        if department_id:
            qs = qs.filter(employee__department_id=department_id)

        date_from = request.query_params.get("date_from")
        date_to = request.query_params.get("date_to")
        if date_from:
            qs = qs.filter(decided_at__date__gte=date_from)
        if date_to:
            qs = qs.filter(decided_at__date__lte=date_to)

        by_department = (
            qs.values("employee__department__id", "employee__department__name")
            .annotate(total_amount=Sum("total_amount"), request_count=Count("id"))
            .order_by("employee__department__name")
        )
        by_employee = (
            qs.values("employee__id", "employee__first_name", "employee__last_name")
            .annotate(total_amount=Sum("total_amount"), request_count=Count("id"))
            .order_by("-total_amount")
        )
        overall_total = qs.aggregate(total=Sum("total_amount"), count=Count("id"))

        return Response(
            {
                "base_currency": getattr(qs.first(), "base_currency_id", None),
                "overall_total_amount": overall_total["total"] or 0,
                "overall_request_count": overall_total["count"] or 0,
                "by_department": list(by_department),
                "by_employee": list(by_employee),
            }
        )
