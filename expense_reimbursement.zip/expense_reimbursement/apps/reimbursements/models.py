from django.conf import settings
from django.db import models

from apps.common.models import TimeStampedModel


class ReimbursementRequest(TimeStampedModel):
    """
    A batch of one or more of an employee's DRAFT expenses submitted
    together for manager approval.

    All monetary totals are captured in the org's base/reporting currency
    at the moment of submission (see reimbursements.services.submit_request)
    so departmental summaries can be aggregated without re-deriving FX
    rates later, and so historical totals remain stable even if rates
    change afterwards.
    """

    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending"
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"
        CANCELLED = "CANCELLED", "Cancelled"

    employee = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="reimbursement_requests"
    )
    manager = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="requests_to_review",
        help_text="The manager who decided (or is expected to decide) this request.",
    )
    status = models.CharField(max_length=16, choices=Status.choices, default=Status.PENDING)
    base_currency = models.ForeignKey("common.Currency", on_delete=models.PROTECT, related_name="+")
    total_amount = models.DecimalField(
        max_digits=14, decimal_places=2, default=0, help_text="Total in base_currency at time of submission."
    )
    employee_note = models.TextField(blank=True)
    submitted_at = models.DateTimeField(null=True, blank=True)
    decided_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["employee", "status"]), models.Index(fields=["manager", "status"])]

    def __str__(self):
        return f"Request #{self.pk} ({self.employee}) - {self.status}"


class ReimbursementRequestItem(models.Model):
    """
    Snapshot linking one Expense to one ReimbursementRequest, freezing the
    original amount/currency and the FX rate used to convert it into the
    request's base currency at submission time.
    """

    request = models.ForeignKey(ReimbursementRequest, on_delete=models.CASCADE, related_name="items")
    expense = models.ForeignKey("expenses.Expense", on_delete=models.PROTECT, related_name="request_items")
    original_amount = models.DecimalField(max_digits=14, decimal_places=2)
    original_currency = models.ForeignKey("common.Currency", on_delete=models.PROTECT, related_name="+")
    exchange_rate_used = models.DecimalField(max_digits=18, decimal_places=8)
    converted_amount = models.DecimalField(max_digits=14, decimal_places=2)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["request", "expense"], name="unique_expense_per_request"
            )
        ]

    def __str__(self):
        return f"Item(request={self.request_id}, expense={self.expense_id})"


class RequestComment(TimeStampedModel):
    """Free-form discussion thread on a request, e.g. manager's rejection reason."""

    request = models.ForeignKey(ReimbursementRequest, on_delete=models.CASCADE, related_name="comments")
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="+")
    message = models.TextField()

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"Comment by {self.author} on request #{self.request_id}"
