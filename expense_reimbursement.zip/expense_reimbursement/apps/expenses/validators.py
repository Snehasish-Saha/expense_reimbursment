from datetime import date

from django.conf import settings
from django.core.exceptions import ValidationError


def validate_not_future_date(value: date):
    if value > date.today():
        raise ValidationError("Expense date cannot be in the future.")


def validate_positive_amount(value):
    if value is None or value <= 0:
        raise ValidationError("Amount must be greater than zero.")


def validate_receipt_file(file):
    ext = file.name.rsplit(".", 1)[-1].lower() if "." in file.name else ""
    if ext not in settings.RECEIPT_ALLOWED_EXTENSIONS:
        raise ValidationError(
            f"Unsupported file type '.{ext}'. Allowed types: {', '.join(settings.RECEIPT_ALLOWED_EXTENSIONS)}."
        )
    if file.size > settings.RECEIPT_MAX_SIZE_BYTES:
        max_mb = settings.RECEIPT_MAX_SIZE_BYTES / (1024 * 1024)
        raise ValidationError(f"Receipt file exceeds the {max_mb:.0f} MB size limit.")
