from rest_framework import serializers

from apps.expenses.models import Expense, ExpenseCategory, Receipt


class ExpenseCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = ExpenseCategory
        fields = ["id", "name", "description", "is_active"]


class ReceiptSerializer(serializers.ModelSerializer):
    class Meta:
        model = Receipt
        fields = ["id", "expense", "file", "original_filename", "content_type", "size", "uploaded_at", "uploaded_by"]
        read_only_fields = ["id", "content_type", "size", "uploaded_at", "uploaded_by"]

    def validate_expense(self, expense):
        if not expense.is_editable:
            raise serializers.ValidationError("Receipts can only be added while the expense is in DRAFT status.")
        return expense

    def create(self, validated_data):
        file = validated_data["file"]
        validated_data.setdefault("original_filename", file.name)
        validated_data["content_type"] = getattr(file, "content_type", "") or ""
        validated_data["size"] = file.size
        return super().create(validated_data)


class ExpenseSerializer(serializers.ModelSerializer):
    receipts = ReceiptSerializer(many=True, read_only=True)
    employee_name = serializers.CharField(source="employee.get_full_name", read_only=True)
    category_name = serializers.CharField(source="category.name", read_only=True)

    class Meta:
        model = Expense
        fields = [
            "id",
            "employee",
            "employee_name",
            "category",
            "category_name",
            "amount",
            "currency",
            "expense_date",
            "merchant",
            "description",
            "status",
            "is_deleted",
            "receipts",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["id", "employee", "status", "is_deleted", "created_at", "updated_at"]

    def validate_amount(self, value):
        if value <= 0:
            raise serializers.ValidationError("Amount must be greater than zero.")
        return value

    def validate(self, attrs):
        # On update, block edits once the expense has left DRAFT.
        if self.instance and not self.instance.is_editable:
            raise serializers.ValidationError(
                "This expense cannot be modified because it is not in DRAFT status "
                "(it is currently part of an active or completed reimbursement request)."
            )
        return attrs


class ExpenseCreateSerializer(ExpenseSerializer):
    """Same shape as ExpenseSerializer; separated for clarity of intent at the create endpoint."""

    class Meta(ExpenseSerializer.Meta):
        pass
