from django.contrib import admin

from apps.expenses.models import Expense, ExpenseCategory, Receipt


class ReceiptInline(admin.TabularInline):
    model = Receipt
    extra = 0


@admin.register(ExpenseCategory)
class ExpenseCategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "is_active")
    search_fields = ("name",)


@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    list_display = ("id", "employee", "category", "amount", "currency", "expense_date", "status", "is_deleted")
    list_filter = ("status", "category", "currency", "is_deleted")
    search_fields = ("description", "merchant", "employee__username")
    inlines = [ReceiptInline]
