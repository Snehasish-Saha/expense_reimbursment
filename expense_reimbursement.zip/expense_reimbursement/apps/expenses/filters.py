import django_filters as df

from apps.expenses.models import Expense


class ExpenseFilter(df.FilterSet):
    date_from = df.DateFilter(field_name="expense_date", lookup_expr="gte")
    date_to = df.DateFilter(field_name="expense_date", lookup_expr="lte")
    amount_min = df.NumberFilter(field_name="amount", lookup_expr="gte")
    amount_max = df.NumberFilter(field_name="amount", lookup_expr="lte")
    category = df.NumberFilter(field_name="category_id")
    status = df.ChoiceFilter(choices=Expense.Status.choices)
    currency = df.CharFilter(field_name="currency_id")
    employee = df.NumberFilter(field_name="employee_id")

    class Meta:
        model = Expense
        fields = ["date_from", "date_to", "amount_min", "amount_max", "category", "status", "currency", "employee"]
