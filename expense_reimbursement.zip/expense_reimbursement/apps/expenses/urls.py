from rest_framework.routers import DefaultRouter

from apps.expenses.views import ExpenseCategoryViewSet, ExpenseViewSet

router = DefaultRouter()
router.register(r"expense-categories", ExpenseCategoryViewSet, basename="expense-category")
router.register(r"expenses", ExpenseViewSet, basename="expense")

urlpatterns = router.urls
