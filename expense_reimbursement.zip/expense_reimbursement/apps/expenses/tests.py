from datetime import date, timedelta
from decimal import Decimal

from django.core.exceptions import ValidationError
from django.test import TestCase

from apps.common.test_helpers import make_category, make_currencies, make_department, make_employee, make_manager
from apps.expenses.models import Expense


class ExpenseModelTests(TestCase):
    def setUp(self):
        self.usd, self.inr = make_currencies()
        self.department = make_department()
        self.manager = make_manager(self.department)
        self.employee = make_employee(self.department, self.manager)
        self.category = make_category()

    def _make_expense(self, **overrides):
        defaults = dict(
            employee=self.employee,
            category=self.category,
            amount=Decimal("500.00"),
            currency=self.inr,
            expense_date=date.today(),
            description="Taxi fare",
        )
        defaults.update(overrides)
        return Expense.objects.create(**defaults)

    def test_expense_is_editable_only_in_draft(self):
        expense = self._make_expense()
        self.assertTrue(expense.is_editable)
        expense.status = Expense.Status.PENDING_APPROVAL
        self.assertFalse(expense.is_editable)

    def test_negative_amount_rejected(self):
        expense = self._make_expense(amount=Decimal("-10.00"))
        with self.assertRaises(ValidationError):
            expense.full_clean()

    def test_future_date_rejected(self):
        expense = self._make_expense(expense_date=date.today() + timedelta(days=1))
        with self.assertRaises(ValidationError):
            expense.full_clean()

    def test_soft_deleted_expense_excluded_by_default_manager_queryset_pattern(self):
        expense = self._make_expense()
        expense.is_deleted = True
        expense.save()
        active = Expense.objects.filter(is_deleted=False)
        self.assertNotIn(expense, active)
