from django.db.models import Q
from django.shortcuts import get_object_or_404
from rest_framework import permissions, status, viewsets
from rest_framework.decorators import action
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.response import Response

from apps.common.exceptions import DomainError
from apps.common.serializers import AuditLogSerializer
from apps.common.services import AuditService
from apps.expenses.filters import ExpenseFilter
from apps.expenses.models import Expense, ExpenseCategory, Receipt
from apps.expenses.serializers import ExpenseCategorySerializer, ExpenseSerializer, ReceiptSerializer


class ExpenseCategoryViewSet(viewsets.ModelViewSet):
    """Reference data: every authenticated user can read; only admins manage it."""

    queryset = ExpenseCategory.objects.all()
    serializer_class = ExpenseCategorySerializer

    def get_permissions(self):
        if self.request.method in permissions.SAFE_METHODS:
            return [permissions.IsAuthenticated()]
        from apps.common.permissions import IsAdmin

        return [IsAdmin()]


class ExpenseViewSet(viewsets.ModelViewSet):
    """
    Employees manage their own expenses (create/edit/delete while DRAFT).
    Managers/Admins get read-only visibility into their reports' expenses
    (needed for reviewing reimbursement requests in context) plus full-text
    search & filtering across categories, status, currency, date and amount
    ranges, per the functional requirements.
    """

    serializer_class = ExpenseSerializer
    filterset_class = ExpenseFilter
    search_fields = ["description", "merchant"]
    ordering_fields = ["expense_date", "amount", "created_at", "status"]

    def get_queryset(self):
        user = self.request.user
        qs = Expense.objects.select_related("employee", "category", "currency").prefetch_related("receipts")
        qs = qs.filter(is_deleted=False)
        if user.is_admin_role:
            return qs
        if user.is_manager:
            return qs.filter(Q(employee_id=user.id) | Q(employee__manager_id=user.id))
        return qs.filter(employee_id=user.id)

    def perform_create(self, serializer):
        expense = serializer.save(employee=self.request.user)
        AuditService.log(self.request.user, "CREATE", expense, changes=serializer.validated_data, request=self.request)

    def perform_update(self, serializer):
        expense = serializer.save()
        AuditService.log(self.request.user, "UPDATE", expense, changes=serializer.validated_data, request=self.request)

    def perform_destroy(self, instance):
        if instance.employee_id != self.request.user.id and not self.request.user.is_admin_role:
            raise DomainError("You can only delete your own expenses.")
        if not instance.is_editable:
            raise DomainError("Only DRAFT expenses can be deleted.")
        instance.is_deleted = True
        instance.save(update_fields=["is_deleted"])
        AuditService.log(self.request.user, "DELETE", instance, request=self.request)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        return Response(status=status.HTTP_204_NO_CONTENT)

    def update(self, request, *args, **kwargs):
        instance = self.get_object()
        if instance.employee_id != request.user.id and not request.user.is_admin_role:
            raise DomainError("You can only edit your own expenses.")
        return super().update(request, *args, **kwargs)

    @action(detail=True, methods=["get"], url_path="audit")
    def audit_history(self, request, pk=None):
        expense = self.get_object()
        history = AuditService.history_for(expense)
        return Response(AuditLogSerializer(history, many=True).data)

    @action(
        detail=True,
        methods=["post"],
        url_path="receipts",
        parser_classes=[MultiPartParser, FormParser],
    )
    def upload_receipt(self, request, pk=None):
        expense = self.get_object()
        if expense.employee_id != request.user.id and not request.user.is_admin_role:
            raise DomainError("You can only attach receipts to your own expenses.")
        if not expense.is_editable:
            raise DomainError("Receipts can only be added while the expense is in DRAFT status.")

        serializer = ReceiptSerializer(data={**request.data, "expense": expense.id})
        serializer.is_valid(raise_exception=True)
        receipt = serializer.save(uploaded_by=request.user)
        AuditService.log(
            request.user, "RECEIPT_UPLOAD", expense, changes={"receipt_id": receipt.id}, request=request
        )
        return Response(ReceiptSerializer(receipt).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["delete"], url_path=r"receipts/(?P<receipt_id>\d+)")
    def delete_receipt(self, request, pk=None, receipt_id=None):
        expense = self.get_object()
        if expense.employee_id != request.user.id and not request.user.is_admin_role:
            raise DomainError("You can only remove receipts from your own expenses.")
        if not expense.is_editable:
            raise DomainError("Receipts can only be removed while the expense is in DRAFT status.")
        receipt = get_object_or_404(Receipt, id=receipt_id, expense=expense)
        receipt.delete()
        AuditService.log(request.user, "RECEIPT_DELETE", expense, changes={"receipt_id": int(receipt_id)}, request=request)
        return Response(status=status.HTTP_204_NO_CONTENT)
