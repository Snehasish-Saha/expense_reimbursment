from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models

from apps.common.models import TimeStampedModel
from apps.expenses.validators import (
    validate_not_future_date,
    validate_positive_amount,
    validate_receipt_file,
)


class ExpenseCategory(models.Model):
    name = models.CharField(max_length=64, unique=True)
    description = models.CharField(max_length=255, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name_plural = "expense categories"
        ordering = ["name"]

    def __str__(self):
        return self.name


class Expense(TimeStampedModel):
    """
    A single expense recorded by an employee.

    Lifecycle (see reimbursements.services for transitions):
      DRAFT -> PENDING_APPROVAL -> REIMBURSED
                     |
                     v
                   DRAFT (on rejection/cancellation of its request, for resubmission)

    Only DRAFT expenses are editable/deletable/eligible to be added to a new
    reimbursement request. This single status field is what prevents an
    expense being claimed twice: once it's attached to an active request it
    moves out of DRAFT and can't be picked up again until that request is
    resolved.
    """

    class Status(models.TextChoices):
        DRAFT = "DRAFT", "Draft"
        PENDING_APPROVAL = "PENDING_APPROVAL", "Pending Approval"
        REIMBURSED = "REIMBURSED", "Reimbursed"

    employee = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="expenses")
    category = models.ForeignKey(ExpenseCategory, on_delete=models.PROTECT, related_name="expenses")
    amount = models.DecimalField(max_digits=14, decimal_places=2, validators=[validate_positive_amount])
    currency = models.ForeignKey("common.Currency", on_delete=models.PROTECT, related_name="+")
    expense_date = models.DateField(validators=[validate_not_future_date])
    merchant = models.CharField(max_length=128, blank=True)
    description = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT)
    is_deleted = models.BooleanField(default=False)

    class Meta:
        ordering = ["-expense_date", "-created_at"]
        indexes = [
            models.Index(fields=["employee", "status"]),
            models.Index(fields=["employee", "expense_date"]),
        ]

    def __str__(self):
        return f"{self.employee} - {self.amount} {self.currency_id} ({self.expense_date})"

    def clean(self):
        if self.amount is not None:
            validate_positive_amount(self.amount)
        if self.expense_date:
            validate_not_future_date(self.expense_date)

    @property
    def is_editable(self):
        return self.status == self.Status.DRAFT and not self.is_deleted


class Receipt(models.Model):
    expense = models.ForeignKey(Expense, on_delete=models.CASCADE, related_name="receipts")
    file = models.FileField(upload_to="receipts/%Y/%m/", validators=[validate_receipt_file])
    original_filename = models.CharField(max_length=255, blank=True)
    content_type = models.CharField(max_length=100, blank=True)
    size = models.PositiveIntegerField(default=0)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name="+"
    )

    class Meta:
        ordering = ["-uploaded_at"]

    def __str__(self):
        return self.original_filename or self.file.name

    def clean(self):
        if not self.expense.is_editable and not self.pk:
            raise ValidationError("Cannot attach receipts to an expense that is not in DRAFT status.")
